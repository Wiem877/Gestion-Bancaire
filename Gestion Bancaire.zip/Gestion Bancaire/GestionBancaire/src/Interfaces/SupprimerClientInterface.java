package Interfaces;

import javax.swing.JFrame;

public class SupprimerClientInterface extends JFrame{

}
