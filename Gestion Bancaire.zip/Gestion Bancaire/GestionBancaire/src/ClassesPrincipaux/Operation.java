package ClassesPrincipaux;

public class Operation {
	public static void retrait(CompteBancaire compte, double montant) {
        // Implémente le retrait
    }

    public static void versement(CompteBancaire compte, double montant) {
        // Implémente le versement
    }

    public static void virement(CompteBancaire source, CompteBancaire destination, double montant) {
        // Implémente le virement
    }
}
